#strPath<-readprojectpath()
#setwd(strPath)
#' Training the GBM,Random Forest , Neural Network and GLM model
#train_model()
#' Validating the test dataset using the GBM model
#predictModel_gbm()
#' Validating the test data using Random Forest model 
#predictModel_rf()
#' Validating the test data using Neural Network model 
#predictModel_nnet()
#' Validating the test data using GLM model 
#predictModel_glm()